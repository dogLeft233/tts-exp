# V3 波形增强头：Step-120 Fit 候选包

## 当前状态

这是完成 120 步 Fit 的候选参数：训练记录绑定 40 条 Fit 语音、20 位 Fit 说话人，未打开 Dev/Confirm；selection record 标记 `NOT_SELECTED`。Multi-TFG Dev 仍在验证中，本包不代表跨模型效果或泛化结论。

## 离线使用

保留此目录结构。运行环境需预装 Python 3.10.12、NumPy 1.26.4、PyTorch 2.5.1+cu124；配置使用 CPU 和各 1 个 PyTorch intra/inter-op 线程。包内不带音频数据、TFG/SyncNet 权重或 Python wheels；波形变换无需 API、网络访问或 TFG 权重。

从本目录根开始，对**原始自然音 RIFF/WAVE**调用增强 CLI 一次：

```bash
python -m scripts.audio_enhancement.enhance_v3_attempt02 \
  --input /path/to/original.wav \
  --output /path/to/enhanced_generator_drive.wav \
  --config runs/cross_tfg_audio_head_20261003/v3_step120_candidate_materialization_fit120_attempt11_attempt01/v3_method_candidate_config.json \
  --metadata /path/to/enhanced_generator_drive.metadata.json
```

CLI 将输入解码、算术平均下混并重采样为 16 kHz 单声道 float32；增强 WAV 只用于所选 TFG 的生成器输入。然后按该 TFG 的输入接口生成视频。CLI 不生成或评分视频。

## 保留原始声音

若原始自然音不是 16 kHz，只有 generator-drive 副本会被 canonicalize；请另行保留原始 PCM WAV，不要用增强 WAV 或 canonicalize 副本替代。视频生成后，用原始 WAV 通过包内真实接口恢复完整原音：

```python
from pathlib import Path
from scripts.audio_enhancement.overdub import mux_original_pcm

info = mux_original_pcm(
    Path("generated_video.mp4"),
    Path("original_natural_pcm.wav"),
    Path("final_with_original_audio.mkv"),
)
print(info)
```

`mux_original_pcm` 也接受 `.mov` 输出；源 WAV 必须是 PCM。它只映射生成视频轨和原 WAV 音轨，视频/音频均 stream-copy，不重编码音频、不使用 `-shortest`，并校验完整解码音频与源 PCM 相同及视频码流/帧时钟未变。mux 时传入未经 canonicalize 的原始 WAV。需要本机已有 `ffmpeg` 与 `ffprobe`。

Stage-A 流程应传入原始音频，由 Stage-A 内部应用增强一次；不要预先增强后再交给 Stage-A，以免重复处理。

## 文件与校验

11 个 payload 是配置 `source_pins` 指定的 7 个原始源码文件、原始 config、checkpoint、training record 和 selection record。它们的文件字节未改写；`BUNDLE_MANIFEST.json` 列出每个 payload 的相对路径、原始来源、字节数和 SHA-256。配置中的 `runs/...` 相对路径必须与本目录布局一起保留。

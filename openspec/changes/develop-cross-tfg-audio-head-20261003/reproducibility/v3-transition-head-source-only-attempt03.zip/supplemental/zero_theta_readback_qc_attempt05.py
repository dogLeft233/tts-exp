#!/usr/bin/env python3
"""Independent stdlib-only validation of the downloaded zero-theta artifacts."""
from __future__ import annotations
import ast, hashlib, json, math, os, stat, struct, zipfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[3]
FILES = ROOT / "runs/cross_tfg_audio_head_20261003/shared_recipient_transition_head_v3_zero_theta_gradient_attempt01_readback_attempt03/files"
EXPECTED = {
 "result.json": {"bytes":5648,"sha256":"68459ce9271c1400ce6f56c5ca056534352bb98edcb1c65bc7b6bb2d28747633"},
 "result_manifest.json": {"bytes":2335,"sha256":"c3b7dc842ca52b4f696b17b2c170c069c71969086a12b86928526930ef77f26b"},
 "zero_theta_diagnostic_arrays.npz": {"bytes":12537,"sha256":"ebd7457feb6547383dadf100def9bf957f4cbcb2839f2f41de13be0c0b6741f1"},
}
INSPECTION_RESPONSE = ROOT / ".codex/scratch/v3_zero_theta_gradient_result_inspection_attempt01/03_inspect_zero_theta_result_attempt01_request.json.response.json"
RUN_RESPONSE = ROOT / ".codex/scratch/v3_zero_theta_gradient_cpu_packet_attempt01/13_run_zero_theta_cpu_attempt01_request.json.response.json"
RUN_REQUEST = ROOT / ".codex/scratch/v3_zero_theta_gradient_cpu_packet_attempt01/13_run_zero_theta_cpu_attempt01_request.json"
STAGE_RECEIPT = ROOT / ".codex/scratch/root_zero_theta_cpu_source_stage_receipt_attempt01.json"
PINNED_EVIDENCE = {'inspection_response': {'path': 'E:\\Documents\\tts-exp\\.codex\\scratch\\v3_zero_theta_gradient_result_inspection_attempt01\\03_inspect_zero_theta_result_attempt01_request.json.response.json', 'bytes': 22789, 'sha256': 'df3049efc0ab999dce906898ad3aa509914519dc92e50acc56b3a255c887eee7'}, 'run_response': {'path': 'E:\\Documents\\tts-exp\\.codex\\scratch\\v3_zero_theta_gradient_cpu_packet_attempt01\\13_run_zero_theta_cpu_attempt01_request.json.response.json', 'bytes': 191, 'sha256': '419eea14301e905238ff8d3b4af9d21ee4b291d8062d8c88fc23e6c0613e5fdf'}, 'run_request': {'path': 'E:\\Documents\\tts-exp\\.codex\\scratch\\v3_zero_theta_gradient_cpu_packet_attempt01\\13_run_zero_theta_cpu_attempt01_request.json', 'bytes': 1681, 'sha256': 'db51fbb418ec7ce3874f95a0c71a960b85a0ff9a30edfef18297ebb4e65ab805'}, 'source_stage_receipt': {'path': 'E:\\Documents\\tts-exp\\.codex\\scratch\\root_zero_theta_cpu_source_stage_receipt_attempt01.json', 'bytes': 4645, 'sha256': '17a8aedcc712f3bc19dc8e73af44a3c0ed835e45e402c71024d014f6174d1b27'}}
EXPECTED_STATUS = "COMPLETE_ENGINEERING_CHECKS_PASS"
ARRAYS = {
 "active_frame_mask_u8":("|u1",(251,)),
 "activity_cells_u8":("|u1",(257,251)),
 "autograd_gradient_f64":("<f8",(3,3)),
 "band_basis_f32":("<f4",(4,257)),
 "baseline_frame_power_f32":("<f4",(50,)),
 "coordinate_absolute_error_f64":("<f8",(3,3)),
 "coordinate_agreement_u8":("|u1",(3,3)),
 "coordinate_allowed_error_f64":("<f8",(3,3)),
 "coordinate_finite_difference_f64":("<f8",(3,3)),
 "direction_matrix_normalized_f64":("<f8",(3,3)),
 "directional_absolute_error_f64":("<f8",(1,)),
 "directional_agreement_u8":("|u1",(1,)),
 "directional_allowed_error_f64":("<f8",(1,)),
 "directional_autograd_f64":("<f8",(1,)),
 "directional_finite_difference_f64":("<f8",(1,)),
 "negative_flux_gate_f32":("<f4",(251,)),
 "negative_relative_flux_f32":("<f4",(251,)),
 "output_frame_power_f32":("<f4",(50,)),
 "positive_flux_gate_f32":("<f4",(251,)),
 "positive_relative_flux_f32":("<f4",(251,)),
 "projected_log_magnitude_mask_db_f32":("<f4",(257,251)),
 "raw_log_magnitude_mask_db_f32":("<f4",(257,251)),
 "smoothed_log_magnitude_mask_db_f32":("<f4",(257,251)),
 "source_frame_power_f32":("<f4",(50,)),
 "stft_frame_centers_source_samples_i64":("<i8",(251,)),
 "theta_zero_f32":("<f4",(3,3)),
 "valid_transition_mask_u8":("|u1",(251,)),
 "video_frame_centers_source_samples_i64":("<i8",(50,)),
}

def sha(raw): return hashlib.sha256(raw).hexdigest()
def safe_regular(path):
    if path.is_symlink() or not path.is_file(): raise RuntimeError("missing/nonregular artifact: "+str(path))
    raw=path.read_bytes()
    if len(raw)>16*1024*1024: raise RuntimeError("artifact exceeds bounded read: "+path.name)
    return raw
def pin(path, expected):
    raw=safe_regular(path)
    actual={"bytes":len(raw),"sha256":sha(raw)}
    if not isinstance(expected, dict) or set(expected) not in ({"bytes","sha256"},{"path","bytes","sha256"}):
        raise RuntimeError(f"invalid expected pin schema for {path.name}")
    expected_identity={"bytes":expected["bytes"],"sha256":expected["sha256"]}
    if actual != expected_identity: raise RuntimeError(f"artifact pin mismatch {path.name}: {actual}")
    if "path" in expected and Path(expected["path"]).resolve(strict=True) != path.resolve(strict=True):
        raise RuntimeError(f"artifact path pin mismatch {path.name}: {path}")
    return raw
def response(path, expected):
    raw=pin(path, expected); value=json.loads(raw)
    if set(value)!={"ok","stdout","stderr","code","timed_out","incomplete_stream","stream_error","truncated"}:
        raise RuntimeError("dispatcher response envelope differs")
    if value["ok"] is not True or value["code"]!=0 or value["timed_out"] or value["incomplete_stream"] or value["stream_error"] is not None or value["stderr"] or value["truncated"]!={"stdout":False,"stderr":False}:
        raise RuntimeError("pinned producer response was not clean")
    return value
def parse_npy(raw):
    if not raw.startswith(b"\x93NUMPY") or len(raw)<10: raise RuntimeError("invalid NPY magic/header")
    major,minor=raw[6],raw[7]
    if (major,minor)==(1,0): header_len=struct.unpack("<H",raw[8:10])[0]; start=10
    elif major in (2,3):
        if len(raw)<12: raise RuntimeError("short NPY v2/v3 header")
        header_len=struct.unpack("<I",raw[8:12])[0]; start=12
    else: raise RuntimeError("unsupported NPY version")
    if header_len>65536 or start+header_len>len(raw): raise RuntimeError("NPY header outside bound")
    encoding="utf-8" if major==3 else "latin1"
    header=ast.literal_eval(raw[start:start+header_len].decode(encoding).strip())
    if not isinstance(header,dict) or set(header)!={"descr","fortran_order","shape"}: raise RuntimeError("NPY header fields differ")
    shape=header["shape"]
    if not isinstance(shape,tuple) or any(type(x) is not int or x<0 for x in shape): raise RuntimeError("invalid NPY shape")
    descr=header["descr"]
    if not isinstance(descr,str) or descr not in {"|u1","<f4","<f8","<i8"}: raise RuntimeError("invalid/unsupported NPY dtype")
    itemsize={"|u1":1,"<f4":4,"<f8":8,"<i8":8}[descr]
    count=math.prod(shape)
    data=raw[start+header_len:]
    if len(data)!=count*itemsize: raise RuntimeError("NPY payload size/shape mismatch")
    return descr,shape,bool(header["fortran_order"]),data
def values(descr,data,shape,fortran):
    fmt={"|u1":"B","<f4":"<f","<f8":"<d","<i8":"<q"}[descr]
    flat=[row[0] for row in struct.iter_unpack(fmt,data)]
    if not fortran or len(shape)<2: return flat
    # Convert Fortran-ordered physical storage to logical C-order for checks.
    logical=[]
    for c_index in range(len(flat)):
        rem=c_index
        coords=[0]*len(shape)
        for axis in range(len(shape)-1,-1,-1):
            coords[axis]=rem%shape[axis]
            rem//=shape[axis]
        f_index=0
        stride=1
        for axis,size in enumerate(shape):
            f_index+=coords[axis]*stride
            stride*=size
        logical.append(flat[f_index])
    return logical
def main():
    insp=response(INSPECTION_RESPONSE,PINNED_EVIDENCE["inspection_response"])
    run=response(RUN_RESPONSE,PINNED_EVIDENCE["run_response"])
    pin(RUN_REQUEST,PINNED_EVIDENCE["run_request"])
    pin(STAGE_RECEIPT,PINNED_EVIDENCE["source_stage_receipt"])
    stage_index=ROOT / ".codex/scratch/v3_zero_theta_gradient_cpu_packet_attempt01/request_index_attempt01.json"
    stage_index_pin=pin(stage_index,{"bytes":5223,"sha256":"7b182b311ea42efac6047af73cf29fe2d7b3afac678bc2a20220ef75bdea5dfc"})
    stage_value=json.loads(STAGE_RECEIPT.read_text(encoding="utf-8"))
    stage_rows=stage_value.get("requests")
    if (stage_value.get("schema")!="root_zero_theta_cpu_source_stage_receipt_v1"
        or stage_value.get("status")!="PASS_13_ACTUAL_RESPONSES"
        or stage_value.get("scope")!="CPU_SYNTHETIC_ENGINEERING_ONLY_NOT_TFG_EFFICACY"
        or stage_value.get("input_index_sha256")!=sha(stage_index_pin)
        or not isinstance(stage_rows,list) or len(stage_rows)!=13):
        raise RuntimeError("actual zero-theta source-stage receipt schema/scope/count mismatch")
    stage_packet=ROOT / ".codex/scratch/v3_zero_theta_gradient_cpu_packet_attempt01"
    for ordinal,row in enumerate(stage_rows):
        if not isinstance(row,dict) or set(row)!={"path","status","index","bytes","sha256"}:
            raise RuntimeError("actual zero-theta source-stage receipt row shape mismatch")
        response_path=Path(row["path"])
        try: response_path.resolve().relative_to(stage_packet.resolve())
        except ValueError as exc: raise RuntimeError("source-stage response path escapes the pinned packet") from exc
        response_pin=pin(response_path,{"bytes":row["bytes"],"sha256":row["sha256"]})
        if row["index"]!=ordinal or row["status"]!="PASS" or not response_path.name.endswith(".response.json") or len(response_pin)!=row["bytes"]:
            raise RuntimeError("source-stage response row status/order/pin mismatch")
    if run["stdout"]!="ZERO_THETA_CPU_WORKER_RETURN_CODE=0\n": raise RuntimeError("foreground worker response mismatch")
    parts=insp["stdout"].splitlines()
    if len(parts)!=2 or parts[1]!="ZERO_THETA_INSPECTOR_RETURN_CODE=0": raise RuntimeError("inspection response framing mismatch")
    inspected=json.loads(parts[0])
    if inspected.get("state")!="TERMINAL_THREE_FILE_SET_VERIFIED" or inspected.get("worker_processes")!=[] or inspected.get("errors")!=[] or inspected.get("unexpected_entries")!=[]:
        raise RuntimeError("pinned read-only inspection is not terminal/clean")
    if not FILES.is_dir() or FILES.is_symlink(): raise RuntimeError("download folder missing or symlinked")
    if {p.name for p in FILES.iterdir()}!=set(EXPECTED): raise RuntimeError("downloaded direct-entry roster mismatch")
    raw_files={name:pin(FILES/name,pin_value) for name,pin_value in EXPECTED.items()}
    result=json.loads(raw_files["result.json"])
    manifest=json.loads(raw_files["result_manifest.json"])
    if result.get("schema")!="cross_tfg_v3_zero_theta_gradient_supplement_result_v1" or manifest.get("schema")!="cross_tfg_v3_zero_theta_gradient_supplement_manifest_v1": raise RuntimeError("result schema mismatch")
    if result.get("status")!=EXPECTED_STATUS or manifest.get("status")!=EXPECTED_STATUS: raise RuntimeError("result terminal status mismatch")
    if result.get("status")!=inspected.get("files",{}).get("result.json",{}).get("json",{}).get("status"): raise RuntimeError("downloaded result differs from inspector result")
    if manifest.get("configuration_sha256")!=inspected.get("files",{}).get("result_manifest.json",{}).get("json",{}).get("configuration_sha256"): raise RuntimeError("manifest config pin differs from inspector")
    if result.get("pinned_sources")!=inspected.get("source_pin_validation",{}).get("pinned_sources"): raise RuntimeError("downloaded source pins differ from inspector")
    if manifest.get("source_pins")!=result.get("pinned_sources"): raise RuntimeError("manifest/result source pin mismatch")
    hard=result.get("hard_checks")
    if not isinstance(hard,dict) or len(hard)!=10 or any(type(v) is not bool or v is not True for v in hard.values()): raise RuntimeError("hard-check set not ten all-true booleans")
    runtime=result.get("runtime")
    if runtime!={"python":"3.10.12","numpy":"1.26.4","torch":"2.5.1+cu124","cuda_initialized":False,"torch_intraop_threads":1,"torch_interop_threads":1}: raise RuntimeError("recorded CPU runtime mismatch")
    scope=result.get("scope")
    if not isinstance(scope,dict) or scope.get("synthetic_probe_only") is not True or any(scope.get(key) is not False for key in ("api_calls","candidate_selection_or_efficacy_claim","confirmation_audio_read","development_audio_read","fit_audio_read","frontend_or_generator_forward","source_or_output_pcm_persisted","training_or_optimizer_step","video_generation_or_syncnet","waveform_persisted")):
        raise RuntimeError("scope boundary mismatch")
    members=manifest.get("output_files")
    expected_members={"result.json":{"bytes":EXPECTED["result.json"]["bytes"],"sha256":EXPECTED["result.json"]["sha256"]},"zero_theta_diagnostic_arrays.npz":{"bytes":EXPECTED["zero_theta_diagnostic_arrays.npz"]["bytes"],"sha256":EXPECTED["zero_theta_diagnostic_arrays.npz"]["sha256"]}}
    actual_members={row.get("path"): {"bytes":row.get("bytes"),"sha256":row.get("sha256")} for row in members if isinstance(row,dict)} if isinstance(members,list) else None
    if actual_members!=expected_members or len(members)!=2: raise RuntimeError("manifest output member seals mismatch")
    if manifest.get("total_output_bytes")!=EXPECTED["result.json"]["bytes"]+EXPECTED["zero_theta_diagnostic_arrays.npz"]["bytes"] or manifest.get("uncompressed_array_bytes")!=850667: raise RuntimeError("manifest output byte totals mismatch")

    arrays={}
    with zipfile.ZipFile(__import__("io").BytesIO(raw_files["zero_theta_diagnostic_arrays.npz"])) as archive:
        infos=archive.infolist()
        expected_members={name+".npy" for name in ARRAYS}
        if len(infos)!=len(expected_members) or {info.filename for info in infos}!=expected_members: raise RuntimeError("NPZ member roster mismatch")
        if archive.testzip() is not None: raise RuntimeError("NPZ CRC failure")
        total_uncompressed=0
        for name,(expected_dtype,expected_shape) in ARRAYS.items():
            info=archive.getinfo(name+".npy")
            if info.file_size>MAX_NPY_MEMBER_BYTES: raise RuntimeError("NPY member exceeds bound")
            npy=archive.read(name+".npy")
            dtype,shape,fortran,data=parse_npy(npy)
            if dtype!=expected_dtype or shape!=expected_shape: raise RuntimeError(f"array dtype/shape mismatch: {name}:{dtype}:{shape}")
            parsed=values(dtype,data,shape,fortran)
            if dtype in ("<f4","<f8") and not all(math.isfinite(x) for x in parsed): raise RuntimeError("nonfinite diagnostic values: "+name)
            if name.endswith("_u8") and any(x not in (0,1) for x in parsed): raise RuntimeError("non-binary mask array: "+name)
            arrays[name]=parsed
            total_uncompressed+=len(data)
    if total_uncompressed!=850667: raise RuntimeError("independent NPZ data byte count mismatch")
    for name in ("theta_zero_f32","raw_log_magnitude_mask_db_f32","smoothed_log_magnitude_mask_db_f32","projected_log_magnitude_mask_db_f32"):
        if any(value!=0 for value in arrays[name]): raise RuntimeError("expected exact zero array failed: "+name)
    # All three masks are same-shape all-zero arrays; byte equality is also
    # checked from the sealed NPY files after ZIP CRC validation.
    for name in ("raw_log_magnitude_mask_db_f32","smoothed_log_magnitude_mask_db_f32","projected_log_magnitude_mask_db_f32"):
        if arrays[name] != arrays["raw_log_magnitude_mask_db_f32"]: raise RuntimeError("zero mask arrays differ")
    for name in ("stft_frame_centers_source_samples_i64","video_frame_centers_source_samples_i64"):
        seq=arrays[name]
        if any(b<=a for a,b in zip(seq,seq[1:])) or seq[0]<0: raise RuntimeError("non-increasing/negative source clock: "+name)
    grad=arrays["autograd_gradient_f64"]
    fd=arrays["coordinate_finite_difference_f64"]
    err=arrays["coordinate_absolute_error_f64"]
    allowed=arrays["coordinate_allowed_error_f64"]
    agree=arrays["coordinate_agreement_u8"]
    for i,(g,f,e,a,ok) in enumerate(zip(grad,fd,err,allowed,agree)):
        if not math.isclose(abs(f-g),e,rel_tol=0.0,abs_tol=1e-15) or e>a or ok!=1:
            raise RuntimeError(f"coordinate finite-difference independent comparison failed at {i}")
    dfd=arrays["directional_finite_difference_f64"][0]
    dag=arrays["directional_autograd_f64"][0]
    derr=arrays["directional_absolute_error_f64"][0]
    dallow=arrays["directional_allowed_error_f64"][0]
    if not math.isclose(abs(dfd-dag),derr,rel_tol=0.0,abs_tol=1e-15) or derr>dallow or arrays["directional_agreement_u8"]!=[1]: raise RuntimeError("directional finite-difference independent comparison failed")
    probe=result.get("probe",{})
    if probe.get("sample_count")!=32000 or probe.get("coordinate_agreement_count")!=9 or probe.get("coordinate_agreement_total")!=9 or probe.get("directional_agreement") is not True: raise RuntimeError("result numerical agreement summary differs")
    report={"schema":"cross_tfg_v3_zero_theta_independent_download_qc_v1","status":"READBACK_QC_PASS_ENGINEERING_ONLY","file_pins":EXPECTED,"inspector_response_sha256":PINNED_EVIDENCE["inspection_response"]["sha256"],"run_response_sha256":PINNED_EVIDENCE["run_response"]["sha256"],"array_count":len(ARRAYS),"uncompressed_array_bytes":total_uncompressed,"all_finite":True,"zero_masks_exact":True,"coordinate_agreement":9,"directional_agreement":True,"scientific_effect_claim":False}
    report_path=Path(__file__).resolve().parent/"independent_readback_qc_attempt05.json"
    if report_path.exists() or report_path.is_symlink(): raise RuntimeError("refusing to overwrite readback QC receipt")
    report_raw=(json.dumps(report,sort_keys=True,separators=(",",":"))+"\n").encode()
    with report_path.open("xb") as stream: stream.write(report_raw); stream.flush(); os.fsync(stream.fileno())
    print(json.dumps(report,sort_keys=True,separators=(",",":")))

MAX_NPY_MEMBER_BYTES = 17 * 1024 * 1024
if __name__ == "__main__": main()

#!/usr/bin/env python3
"""Small NumPy-only arithmetic diagnosis for the three V3 activity-cell deltas."""
from __future__ import annotations

import hashlib
import importlib.util
import json
import math
import os
import sys
from pathlib import Path

import numpy as np

ROOT = Path(__file__).resolve().parents[3]
CPU_DIR = ROOT / "runs/cross_tfg_audio_head_20261003/shared_recipient_transition_head_v3_cpu_qualification_attempt02_readback_attempt01/files"
ZERO_DIR = ROOT / "runs/cross_tfg_audio_head_20261003/shared_recipient_transition_head_v3_zero_theta_gradient_attempt01_readback_attempt03/files"
CPU_CONFIG = ROOT / "runs/cross_tfg_audio_head_20261003/shared_recipient_transition_head_v3_cpu_qualification_attempt02/qualification_config.json"
ZERO_CONFIG = ROOT / "runs/cross_tfg_audio_head_20261003/shared_recipient_transition_head_v3_zero_theta_gradient_attempt01/qualification_config.json"
ZERO_NUMPY_RESULT = ROOT / "runs/cross_tfg_audio_head_20261003/shared_recipient_transition_head_v3_zero_theta_numpy_audit_attempt04/output/independent_result.json"
SYNTHESIS_SOURCE = ROOT / "scripts/experiments/cross_tfg_audio_head_20261003/independent_numpy_zero_theta_audit_attempt04.py"
STFT_SOURCE = ROOT / "scripts/experiments/cross_tfg_audio_head_20261003/independent_numpy_audit_shared_recipient_transition_head_v3_attempt03.py"
PRODUCER_SOURCE = ROOT / "scripts/experiments/cross_tfg_audio_head_20261003/qualify_shared_recipient_transition_head_v3_zero_theta_gradient_attempt01.py"
HEAD_SOURCE = ROOT / "scripts/audio_enhancement/shared_recipient_transition_head_v3.py"

PINS = {
    "cpu_matrices": (CPU_DIR / "qualification_matrices.npz", 3019026, "ac84bd7327f68d9b4e1199bb6a401abc188500a34acf2de69a8469a6a6933818"),
    "zero_arrays": (ZERO_DIR / "zero_theta_diagnostic_arrays.npz", 12537, "ebd7457feb6547383dadf100def9bf957f4cbcb2839f2f41de13be0c0b6741f1"),
    "cpu_config": (CPU_CONFIG, 10721, "0abfbb9797a84254e6d0a6e72266862a079e5066f2fec394e0796b0c2664d2f5"),
    "zero_config": (ZERO_CONFIG, 5396, "594f5e4ff86e373d99a69815596148b72e7bdf58f9b9d6c2d65c37e4ebdbd1dd"),
    "numpy_audit_result": (ZERO_NUMPY_RESULT, 18354, "5035cd6cc9920eabb49033853629ef088f3f2664234db9bd6ee7e43315577fc4"),
    "synthesis_source": (SYNTHESIS_SOURCE, 44759, "27f472cb6e6ba15a8a6a6dadf7b541856a565d8c97817bcc059e92d720fd60bb"),
    "stft_source": (STFT_SOURCE, 98390, "ed540178ae9564a567f5939dd1fdb8560d422bf1a301d8d3f01c06da972fe40b"),
    "producer_source": (PRODUCER_SOURCE, 27243, "6193181ccb890fe1f9b49d97e7ab2960499d511816693d3de48669eca4a3c536"),
    "head_source": (HEAD_SOURCE, 32233, "77acdff03cca22261852f48364cbc75263db58a14cb565c08aa0d268afca6e87"),
}
EXPECTED_CELLS = [[213, 6], [247, 4], [256, 8]]
ACTIVITY_FLOOR = np.float32(1.0e-6)


def sha_bytes(raw: bytes) -> str:
    return hashlib.sha256(raw).hexdigest()


def read_pinned(name: str) -> bytes:
    path, expected_bytes, expected_sha = PINS[name]
    if path.is_symlink() or not path.is_file():
        raise RuntimeError(f"pinned input is absent or unsafe: {name}")
    raw = path.read_bytes()
    if len(raw) != expected_bytes or sha_bytes(raw) != expected_sha:
        raise RuntimeError(f"pinned input changed: {name}")
    return raw


def load_module(name: str, path: Path):
    spec = importlib.util.spec_from_file_location(name, path)
    if spec is None or spec.loader is None:
        raise ImportError(f"cannot load pinned helper: {name}")
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    spec.loader.exec_module(module)
    if "torch" in sys.modules:
        raise RuntimeError("Torch was imported during this NumPy-only arithmetic diagnosis")
    return module


def centered_stft_modes(samples: np.ndarray, config: dict, stft_module):
    options = config["head_constructor"]
    n_fft = int(options["n_fft"])
    hop = int(options["hop_length"])
    if (n_fft, hop, int(options["win_length"])) != (512, 128, 512):
        raise RuntimeError("unexpected pinned diagnostic STFT geometry")
    if options["window_kind"] != "hann" or options["window_periodic"] is not True:
        raise RuntimeError("unexpected pinned diagnostic window")
    if options["stft_center"] is not True or options["stft_pad_mode"] != "reflect":
        raise RuntimeError("unexpected pinned diagnostic padding")
    spectrum_c64, magnitude_c64 = stft_module._centered_stft(samples, config, np)

    source = np.asarray(samples, dtype=np.float32)
    padded = np.pad(source, (n_fft // 2, n_fft // 2), mode="reflect")
    frames = np.lib.stride_tricks.sliding_window_view(padded, n_fft)[::hop]
    window = stft_module._hann_periodic(n_fft, np)
    windowed_f32 = np.asarray(frames * window[None, :], dtype=np.float32)
    spectrum_c128 = np.fft.rfft(windowed_f32, n=n_fft, axis=1).T
    magnitude_c128 = np.abs(spectrum_c128)
    if spectrum_c64.shape != magnitude_c64.shape or spectrum_c64.shape != spectrum_c128.shape:
        raise RuntimeError("independent STFT variants have inconsistent shapes")

    real32 = np.asarray(spectrum_c64.real, dtype=np.float32)
    imag32 = np.asarray(spectrum_c64.imag, dtype=np.float32)
    square_sum32 = np.asarray(real32 * real32 + imag32 * imag32, dtype=np.float32)
    magnitude_sqrt32 = np.sqrt(square_sum32, dtype=np.float32)
    magnitude_hypot32 = np.hypot(real32, imag32).astype(np.float32, copy=False)
    return {
        "spectrum_c64": spectrum_c64,
        "magnitude_c64": np.asarray(magnitude_c64, dtype=np.float32),
        "magnitude_c128": np.asarray(magnitude_c128, dtype=np.float64),
        "magnitude_sqrt32": magnitude_sqrt32,
        "magnitude_hypot32": magnitude_hypot32,
    }


def main() -> None:
    if "torch" in sys.modules:
        raise RuntimeError("Torch was imported before the NumPy-only diagnostic began")
    observed_pins = {}
    for name, (path, size, digest) in PINS.items():
        read_pinned(name)
        observed_pins[name] = {"path": str(path), "bytes": size, "sha256": digest}

    cpu_config = json.loads(CPU_CONFIG.read_text(encoding="utf-8"))
    zero_config = json.loads(ZERO_CONFIG.read_text(encoding="utf-8"))
    if cpu_config.get("head_constructor", {}).get("activity_floor") != 1.0e-6:
        raise RuntimeError("CPU02 activity floor differs from the frozen 1e-6 value")
    zero_scope = zero_config.get("scope", {})
    if (
        zero_scope.get("synthetic_probe_only") is not True
        or zero_scope.get("development_audio_read") is not False
        or zero_scope.get("confirmation_audio_read") is not False
        or zero_scope.get("training_or_optimizer_step") is not False
        or zero_scope.get("cuda_initialized") is not False
    ):
        raise RuntimeError("zero-theta source scope differs from the pinned synthetic CPU contract")

    synthesis = load_module("pinned_zero_theta_synthesis", SYNTHESIS_SOURCE)
    stft = load_module("pinned_shared_transition_numpy_stft", STFT_SOURCE)
    with np.load(PINS["cpu_matrices"][0], allow_pickle=False) as archive:
        source_saved = np.asarray(archive["synthetic_source_float32"], dtype=np.float32).copy()
        torch_spectrum_real = np.asarray(archive["synthetic_source_stft_real_f32"], dtype=np.float32).copy()
        torch_spectrum_imag = np.asarray(archive["synthetic_source_stft_imag_f32"], dtype=np.float32).copy()
    with np.load(PINS["zero_arrays"][0], allow_pickle=False) as archive:
        worker_activity = np.asarray(archive["activity_cells_u8"], dtype=np.uint8).copy()

    probe = cpu_config["synthetic_probe"]
    source_analytic = np.asarray(synthesis._synthesize_waveform(probe, np), dtype=np.float32)
    if source_saved.shape != (32000,) or source_analytic.shape != source_saved.shape:
        raise RuntimeError("pinned probe source shape differs from the expected 32000 samples")
    if worker_activity.shape != (257, 251):
        raise RuntimeError("saved Torch activity array has an unexpected shape")

    saved_modes = centered_stft_modes(source_saved, cpu_config, stft)
    analytic_modes = centered_stft_modes(source_analytic, cpu_config, stft)
    numpy_activity = (saved_modes["magnitude_c64"] > ACTIVITY_FLOOR).astype(np.uint8)
    analytic_activity = (analytic_modes["magnitude_c64"] > ACTIVITY_FLOOR).astype(np.uint8)
    if torch_spectrum_real.shape != worker_activity.shape or torch_spectrum_imag.shape != worker_activity.shape:
        raise RuntimeError("CPU02 saved Torch STFT component arrays have unexpected shapes")
    torch_spectrum_hypot = np.hypot(torch_spectrum_real, torch_spectrum_imag).astype(np.float32)
    torch_component_activity = (torch_spectrum_hypot > ACTIVITY_FLOOR).astype(np.uint8)
    torch_component_activity_mismatches = np.argwhere(torch_component_activity != worker_activity).tolist()
    if torch_component_activity_mismatches:
        raise RuntimeError("saved CPU02 Torch STFT components do not reproduce the zero worker activity cells")
    mismatch = np.argwhere(numpy_activity != worker_activity).tolist()
    if mismatch != EXPECTED_CELLS:
        raise RuntimeError(f"activity mismatch coordinates differ from audited result: {mismatch}")
    torch_numpy_real_delta = torch_spectrum_real - saved_modes["spectrum_c64"].real.astype(np.float32)
    torch_numpy_imag_delta = torch_spectrum_imag - saved_modes["spectrum_c64"].imag.astype(np.float32)

    source_diff64 = source_analytic.astype(np.float64) - source_saved.astype(np.float64)
    ulp = float(np.spacing(ACTIVITY_FLOOR))
    per_cell = []
    for freq_index, frame_index in EXPECTED_CELLS:
        worker_bit = int(worker_activity[freq_index, frame_index])
        entry = {
            "frequency_bin": freq_index,
            "frame_index": frame_index,
            "worker_torch_activity_bit": worker_bit,
            "cpu02_saved_torch_stft_real_f32": float(torch_spectrum_real[freq_index, frame_index]),
            "cpu02_saved_torch_stft_imag_f32": float(torch_spectrum_imag[freq_index, frame_index]),
            "cpu02_saved_torch_stft_component_hypot_float32": float(torch_spectrum_hypot[freq_index, frame_index]),
            "cpu02_saved_torch_stft_component_hypot_delta_from_floor": float(torch_spectrum_hypot[freq_index, frame_index] - ACTIVITY_FLOOR),
            "numpy_saved_source_stft_real_c64": float(saved_modes["spectrum_c64"].real[freq_index, frame_index]),
            "numpy_saved_source_stft_imag_c64": float(saved_modes["spectrum_c64"].imag[freq_index, frame_index]),
            "torch_component_minus_numpy_stft_real": float(torch_spectrum_real[freq_index, frame_index] - saved_modes["spectrum_c64"].real[freq_index, frame_index]),
            "torch_component_minus_numpy_stft_imag": float(torch_spectrum_imag[freq_index, frame_index] - saved_modes["spectrum_c64"].imag[freq_index, frame_index]),
            "activity_floor": float(ACTIVITY_FLOOR),
            "numpy_saved_source_magnitude_c64": float(saved_modes["magnitude_c64"][freq_index, frame_index]),
            "numpy_analytic_source_magnitude_c64": float(analytic_modes["magnitude_c64"][freq_index, frame_index]),
            "numpy_saved_source_magnitude_before_complex64_cast": float(saved_modes["magnitude_c128"][freq_index, frame_index]),
            "numpy_analytic_source_magnitude_before_complex64_cast": float(analytic_modes["magnitude_c128"][freq_index, frame_index]),
            "numpy_saved_source_magnitude_sqrt_float32": float(saved_modes["magnitude_sqrt32"][freq_index, frame_index]),
            "numpy_saved_source_magnitude_hypot_float32": float(saved_modes["magnitude_hypot32"][freq_index, frame_index]),
        }
        for label in (
            "numpy_saved_source_magnitude_c64",
            "numpy_analytic_source_magnitude_c64",
            "numpy_saved_source_magnitude_before_complex64_cast",
            "numpy_analytic_source_magnitude_before_complex64_cast",
            "numpy_saved_source_magnitude_sqrt_float32",
            "numpy_saved_source_magnitude_hypot_float32",
        ):
            value = entry[label]
            entry[label + "_delta_from_floor"] = value - float(ACTIVITY_FLOOR)
            entry[label + "_delta_from_floor_in_float32_ulps"] = (value - float(ACTIVITY_FLOOR)) / ulp
            entry[label + "_active"] = value > float(ACTIVITY_FLOOR)
        entry["analytic_minus_saved_c64_magnitude"] = (
            entry["numpy_analytic_source_magnitude_c64"] - entry["numpy_saved_source_magnitude_c64"]
        )
        entry["torch_components_minus_numpy_saved_c64_magnitude"] = (
            entry["cpu02_saved_torch_stft_component_hypot_float32"] - entry["numpy_saved_source_magnitude_c64"]
        )
        entry["torch_components_minus_numpy_analytic_c64_magnitude"] = (
            entry["cpu02_saved_torch_stft_component_hypot_float32"] - entry["numpy_analytic_source_magnitude_c64"]
        )
        entry["saved_source_c64_vs_before_cast_delta"] = (
            entry["numpy_saved_source_magnitude_c64"] - entry["numpy_saved_source_magnitude_before_complex64_cast"]
        )
        entry["worker_bit_matches_numpy_saved_source"] = worker_bit == int(
            entry["numpy_saved_source_magnitude_c64"] > float(ACTIVITY_FLOOR)
        )
        entry["worker_bit_matches_numpy_analytic_source"] = worker_bit == int(
            entry["numpy_analytic_source_magnitude_c64"] > float(ACTIVITY_FLOOR)
        )
        per_cell.append(entry)

    summary = {
        "schema": "cross_tfg_v3_zero_theta_activity_cell_arithmetic_diagnostic_v1",
        "status": "COMPLETE_NUMPY_ONLY_ARITHMETIC_DIAGNOSTIC",
        "scope": {
            "historical_synthetic_probe_only": True,
            "torch_imported": False,
            "model_or_frontend_run": False,
            "training_or_optimizer": False,
            "development_audio_read": False,
            "confirmation_audio_read": False,
            "activity_floor_changed": False,
        },
        "runtime": {"numpy_version": np.__version__, "python_version": list(sys.version_info[:3])},
        "source_pins": observed_pins,
        "activity_floor": float(ACTIVITY_FLOOR),
        "torch_activity_cell_count": int(worker_activity.sum()),
        "cpu02_torch_stft_component_hypot_activity_cell_count": int(torch_component_activity.sum()),
        "cpu02_torch_stft_component_hypot_matches_zero_worker_all_cells": True,
        "numpy_saved_source_c64_activity_cell_count": int(numpy_activity.sum()),
        "numpy_analytic_source_c64_activity_cell_count": int(analytic_activity.sum()),
        "torch_numpy_stft_component_difference": {
            "max_abs_real_difference": float(np.max(np.abs(torch_numpy_real_delta))),
            "max_abs_imag_difference": float(np.max(np.abs(torch_numpy_imag_delta))),
            "nonidentical_real_component_count": int(np.count_nonzero(torch_numpy_real_delta)),
            "nonidentical_imag_component_count": int(np.count_nonzero(torch_numpy_imag_delta)),
        },
        "torch_vs_numpy_saved_source_mismatch_cells": mismatch,
        "numpy_saved_vs_analytic_source_mismatch_cells": np.argwhere(numpy_activity != analytic_activity).tolist(),
        "source_synthesis_difference": {
            "sample_count": int(source_saved.size),
            "different_sample_count": int(np.count_nonzero(source_analytic != source_saved)),
            "max_absolute_difference": float(np.max(np.abs(source_diff64))),
            "rms_difference": float(np.sqrt(np.mean(source_diff64 * source_diff64))),
            "saved_source_f32le_sha256": sha_bytes(np.ascontiguousarray(source_saved.astype("<f4", copy=False)).tobytes()),
            "analytic_source_f32le_sha256": sha_bytes(np.ascontiguousarray(source_analytic.astype("<f4", copy=False)).tobytes()),
        },
        "mismatch_cells": per_cell,
        "interpretation": "The CPU02 archive contains the Torch source STFT real/imaginary float32 arrays for the same frozen probe. Their float32 hypot threshold reproduces all 64,503 zero-worker activity bits. Comparing those components with the independent NumPy STFT on the identical CPU02 saved waveform isolates the three binary disagreements to Torch-versus-NumPy STFT arithmetic, not a changed threshold. The separately synthesized NumPy waveform shifts two NumPy magnitudes across the floor, showing that synthesis rounding can affect this edge check, but it is not needed to explain the saved-Torch-versus-saved-source-NumPy comparison.",
        "interpretation_limit": "The CPU02 artifact saves Torch complex STFT components, not the exact result bits of Torch's complex absolute-value kernel. The float32 hypot/sqrt variants agree on every activity bit, but their final magnitude float bits are not claimed to be byte-identical to Torch abs.",
    }
    raw = (json.dumps(summary, sort_keys=True, separators=(",", ":"), allow_nan=False) + "\n").encode("utf-8")
    out = Path(__file__).resolve().parent / "activity_cell_diagnostic_attempt03.json"
    if out.exists() or out.is_symlink():
        raise FileExistsError("refusing to overwrite the arithmetic diagnostic")
    with out.open("xb") as stream:
        stream.write(raw)
        stream.flush()
        os.fsync(stream.fileno())
    print(json.dumps(summary, sort_keys=True, separators=(",", ":"), allow_nan=False))


if __name__ == "__main__":
    main()
